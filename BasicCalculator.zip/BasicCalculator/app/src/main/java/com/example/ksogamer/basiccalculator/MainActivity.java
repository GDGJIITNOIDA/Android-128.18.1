package com.example.ksogamer.basiccalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button addButton,subtractButton,multiplyButton,divideButton,equalButton,clearAllButton;
    EditText firstInputEditText,secondInputEditText;
    TextView operationsTextView,answerTextView;
    String inputOne,inputTwo;
    Integer operand1,operand2,answer;

    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addButton = findViewById(R.id.addButton);
        subtractButton = findViewById(R.id.subtractButton);
        multiplyButton = findViewById(R.id.multiplyButton);
        divideButton = findViewById(R.id.divideButton);
        equalButton = findViewById(R.id.equalButton);
        clearAllButton = findViewById(R.id.clearAllButton);

        firstInputEditText = findViewById(R.id.inputOneEditText);
        secondInputEditText = findViewById(R.id.inputTwoEditText);

        operationsTextView = findViewById(R.id.operationTextView);
        answerTextView = findViewById(R.id.answerTextView);


        clearAllButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                firstInputEditText.setText("");
                secondInputEditText.setText("");
                operationsTextView.setText("");

            }
        });
    }

    public boolean validateEditText(){

        inputOne = firstInputEditText.getText().toString().trim();
        inputTwo = secondInputEditText.getText().toString().trim();

        if(!TextUtils.isEmpty(inputOne) && !TextUtils.isEmpty(inputTwo) && inputOne != null && inputTwo != null){

            operand1 = Integer.parseInt(inputOne);
            operand2 = Integer.parseInt(inputTwo);

            return true;

        }else{

            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
            return false;
        }
    }


    @Override
    public void onClick(View v) {
        int clickedViewId = v.getId();

        switch (clickedViewId){

            case R.id.addButton:
                if(validateEditText()) {
                operationsTextView.setText("+");
                answer = operand1 + operand2;
                answerTextView.setText("Answer  = " + answer.toString());
                break;
            }


            case R.id.subtractButton:
                if(validateEditText()) {
                    operationsTextView.setText("-");
                    answer = operand1 - operand2;
                    answerTextView.setText("Answer  = " + answer.toString());
                    break;
                }

            case R.id.multiplyButton:
                if(validateEditText()) {
                    operationsTextView.setText("*");
                    answer = operand1 * operand2;
                    answerTextView.setText("Answer  = " + answer.toString());
                    break;
                }


            case R.id.divideButton:
                if(validateEditText()) {
                    operationsTextView.setText("/");
                    answer = operand1 / operand2;
                    answerTextView.setText("Answer  = " + answer.toString());
                    break;
                }

        }
    }
}
